
<?php 
require('db.php');

$a=$_GET['pid'];



if($con){
	echo"connection successful";
    $query = "UPDATE  `plots` SET status='2' WHERE  pid='$a'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert(" Order Updated successfully  ");
            window.location="vplot.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="vplot.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}

?>









