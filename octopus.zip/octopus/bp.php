<?php
include("sauth.php");
$db="ranchers";
$user="root";
$pass="";
$server="localhost";
$a = $_GET['pid'];

$b = $_SESSION['username'];

$con=mysqli_connect($server,$user,$pass,$db);
if($con){
	
	$sql="select * from products where pid='$a'";
    $result=mysqli_query($con,$sql);
    $data=mysqli_fetch_array($result);
    $pid=$data['pid'];
    $fname=$data['fname'];
    $pname=$data['pname'];
    $pimage=$data['pimage'];
    $pprice=$data['pprice'];
    $about=$data['about'];


    $sqli="INSERT into `orders` (oid,pid,fname,uname,pname,pimage,pprice,about) VALUES ('','$pid','$fname','$b','$pname','$pimage','$pprice','$about') ";
$result1=mysqli_query($con,$sqli);

	if($result1){
		echo"Record Inserted";?>
		<script type="text/javascript">
            window.alert("Your Order Was successful ");
            window.location="vo.php";
            </script>
			<?php 
}else{
	echo"connection error";
}
}
?>