
<?php 
require('db.php');
if (isset($_POST['submit'])) {
$a=$_POST['fid'];
$b=$_POST['response'];


if($con){
	echo"connection successful";
    $query = "UPDATE  `feedback` SET resp='$b',sta='1' WHERE  fid='$a'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Response Sent successfully  ");
            window.location="vvff.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="vvff.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}
}

?>








