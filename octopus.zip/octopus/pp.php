
<?php 
require('db.php');

$a=$_GET['oid'];



if($con){
	echo"connection successful";
    $query = "UPDATE  `orders` SET status='completed',sta='1' WHERE  oid='$a'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Updated successfully  ");
            window.location="pay.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="pay.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}


?>








