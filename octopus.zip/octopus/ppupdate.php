
<?php 
require('db.php');

$a=$_POST['pid'];
$b=$_POST['fname'];
$c=$_POST['pname'];
$d=$_POST['pimage'];
$e=$_POST['about'];
$f=$_POST['images'];
$g=$_POST['price'];
if(empty($d)){

$d=$f;


if($con){
	echo"connection successful";
    $query = "UPDATE  `products` SET fname='$b',pname='$c',pimage='$d',pprice='$g',about='$e' WHERE  pid='$a'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Updated successfully  ");
            window.location="viewp.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="viewp.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}
}else{
    if($con){
		echo"connection successful";
		$query = "UPDATE  `products` SET fname='$b',pname='$c',pimage='$d',pprice='$g',about='$e' WHERE  pid='$a'";
	
		if (mysqli_query($con, $query)) {
				   echo "New record created successfully";?>
						   <script type="text/javascript">
				window.alert("Updated successfully  ");
				window.location="viewp.php";
				</script>
				<?php 
				}
		else{
			echo"Record not inserted";?>
			<script type="text/javascript">
				window.alert("Updated failed ");
				window.location="viewp.php";
				</script>
				<?php 
		}
	}
	else{
		echo"connection error";
	
	}
}
?>









