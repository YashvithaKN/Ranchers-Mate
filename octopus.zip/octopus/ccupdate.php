
<?php 
require('db.php');

$a=$_POST['cid'];
$b=$_POST['cname'];
$c=$_POST['ctype'];
$d=$_POST['fimage'];
$e=$_POST['cabout'];
$f=$_POST['images'];
if(empty($d)){

$d=$f;


if($con){
	echo"connection successful";
    $query = "UPDATE  `crop` SET cname='$b',region='$c',cimage='$d',about='$e' WHERE  cid='$a'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Updated successfully  ");
            window.location="mc.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="mc.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}
}else{
    if($con){
		echo"connection successful";
		$query = "UPDATE  `crop` SET cname='$b',region='$c',cimage='$d',about='$e' WHERE  cid='$a'";
	
		if (mysqli_query($con, $query)) {
				   echo "New record created successfully";?>
						   <script type="text/javascript">
				window.alert("Updated successfully  ");
				window.location="mc.php";
				</script>
				<?php 
				}
		else{
			echo"Record not inserted";?>
			<script type="text/javascript">
				window.alert("Updated failed ");
				window.location="mc.php";
				</script>
				<?php 
		}
	}
	else{
		echo"connection error";
	
	}
}
?>








