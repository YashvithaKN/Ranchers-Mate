
<?php 
require('db.php');

$a=$_GET['oid'];



if($con){
	echo"connection successful";
    $query = "UPDATE  `orders` SET status='cancelled',sta='5' WHERE  oid='$a' AND status='pending'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Updated successfully  ");
            window.location="vo.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="vo.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}


?>








