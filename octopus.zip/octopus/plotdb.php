<?php 
	session_start();
	
	include("db.php");	
	 {	
		//$res = $conn->query($sql);
		
		// if ($res->num_rows==0)
    {
		
		 $a = $_POST['fname'];
		 $b = $_POST['pid'];
         $c = $_POST['region'];
         $d = $_POST['price'];
         $e = $_POST['about'];
         $f = $_POST['cat'];
$g=$_POST['fname'];
		 $sql = "INSERT INTO plots (fname,pid,region,stype,pprice,about,status,nana) VALUES ('$a','$b','$c','$f','$d','$e','','$g')";
			if($con->query($sql))
			{?>
                
				
               <script type="text/javascript">
            window.alert("successfully INFO Added");
            window.location="mplot.php";
            </script>
			<?php 
			}
			else
			{
				echo "failed";
			}
		
			
		}
     }
?>

