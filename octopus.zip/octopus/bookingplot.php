
<?php 
include("sauth.php");
$a=$_SESSION['username'];
require('db.php');

$b=$_GET['pid'];

if($con){
	echo"connection successful";
    $query = "UPDATE  `plots` SET status='1',nana='$a' WHERE  pid='$b'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Response Sent successfully  ");
            window.location="rplot.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="rplot.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}


?>








