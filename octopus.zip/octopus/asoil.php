<!doctype html>
<?Php include("auth.php"); ?>
<html class="fixed">
	<head>

		<!-- Basic -->
		<meta charset="UTF-8">

		<title>Dashboard-Admin</title>
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

		<!-- Theme CSS -->
		<link rel="stylesheet" href="assets/stylesheets/theme.css" />

		<!-- Skin CSS -->
		<link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

		<!-- Head Libs -->
		<script src="assets/vendor/modernizr/modernizr.js"></script>

	</head>
    <?php
require('db.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['cat'])){
        // removes backslashes
	$cat = stripslashes($_REQUEST['cat']);
        //escapes special characters in a string
	$cat = mysqli_real_escape_string($con,$cat); 
    
	$region = stripslashes($_REQUEST['region']);
	$region = mysqli_real_escape_string($con,$region);
	
	
	
        $query = "INSERT into `soil` (sname,sarea)
VALUES ('$cat','$region')";
        $result = mysqli_query($con,$query);
        if($result){
           echo"Record inserted";?>
		<script type="text/javascript">
            window.alert("successfully INFO Added");
            window.location="vsoil.php";
            </script>
			<?php 
        }
    }else{
?>
	<body>
		<section class="body">

			<!-- start: header -->
			<header class="header">
				<div class="logo-container">
					<a href="#" class="logo">
						<img src="assets/images/logo.png"  height="40" alt="Porto Admin" />
					</a>
					<div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
					</div>
				</div>
			
				<!-- start: search & user box -->
				<div class="header-right">
			
					<form action="pages-search-results.html" class="search nav-form">
						
					</form>
			
					
			
					
			
					<span class="separator"></span>
			
					<div id="userbox" class="userbox">
						<a href="#" data-toggle="dropdown">
							<figure class="profile-picture">
								<img src="assets/images/!logged-user.jpg" alt="Joseph Doe" class="img-circle" data-lock-picture="assets/images/!logged-user.jpg" />
							</figure>
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name"><?php echo $_SESSION['username']?></span>
								<span class="role">ADMIN</span>
							</div>
			
							<i class="fa custom-caret"></i>
						</a>
			
						<div class="dropdown-menu">
							<ul class="list-unstyled">
								<li class="divider"></li>
								
								<li>
									<a role="menuitem" tabindex="-1" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- end: search & user box -->
			</header>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">
				
					<!-- <div class="sidebar-header">
						<div class="sidebar-title">
							Navigation
						</div>
						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
						</div>
					</div> -->
				
					<div class="nano">
						<div class="nano-content">
							<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-main">
								<li >
									<a href="dashboard.php">
										<i class="fa fa-home" aria-hidden="true"></i>
										<span>Dashboard</span>
									</a>
								</li>
								<li>
									<a href="asoil.php">
										<!-- <span class="pull-right label label-primary">182</span> -->
										<i class="fa fa-search" aria-hidden="true"></i>
										<span>Add Soil Details</span>
									</a>
								</li>
								<li >
									<a href="vsoil.php">
										<i class="fa fa-search" aria-hidden="true"></i>
										<span>Manage Soil Details</span>
									</a>
									
								</li>
								<li >
									<a href="af.php">
										<i class="fa fa-tree" aria-hidden="true"></i>
										<span>Add Fertilizers</span>
									</a>
									
								</li>
								<li>
									<a href="viewf.php">
										<i class="fa  fa-money" aria-hidden="true"></i>
										<span>Manage Fertilizers</span>
									</a>
									
								</li>
								<li>
									<a href="ac.php">
										<i class="fa  fa-money" aria-hidden="true"></i>
										<span>Add crop details</span>
									</a>
									
								</li>

								<li class="nav-active" style="background-color:#27303F;">
									<a href="mc.php">
										<i class="fa  fa-money" aria-hidden="true"></i>
										<span>Manage crop details</span>
									</a>
									
								</li>

								<li>
									<a href="vuu.php">
										<i class="fa  fa-money" aria-hidden="true"></i>
										<span>View Users</span>
									</a>
									
								</li>

								<li>
									<a href="vff.php">
										<i class="fa  fa-money" aria-hidden="true"></i>
										<span>View Farmers</span>
									</a>
									
								</li>

								
							
								
								
								
									
							   
							</ul>
							</nav>
				
							
						</div>
				
					</div>
				
				</aside>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>ADD SOIL DETAILS</h2>
					
						<div class="right-wrapper pull-right">
							
					
							
						</div>
					</header>

					<!-- start: page -->
						
									
									
										<form class="form-horizontal form-bordered" action="" method="post">
											
						
											
						
											
						
											
                                            <div class="form-group">
												<label class="col-md-3 control-label" for="inputSuccess">Soil Type</label>
												<div class="col-md-6">
													
													<select class="form-control input-sm mb-md" name= "cat" required>
														<option>Select Soil Category</option>
														<option>Red and Red Loamy Soil</option>
														<option>Black Soil </option>
														<option>Laterite Soil</option>
                                                        <option>Coastal Alluvial Soil</option>
														<option>Dark Brown Clayey Soil</option>
														<option>Mixed Red and Black Soil</option>
													</select>
												</div>
											</div>
                                            <div class="form-group">
												<label class="col-md-3 control-label" for="inputSuccess">Region </label>
												<div class="col-md-6">
													
													<select class="form-control input-sm mb-md" name= "region" required>
														<option>Select Region</option>
														<option>Mysuru/Mysore</option>
														<option>Bengaluru/Bangalore Rural</option>
														<option>Bengaluru/Bangalore Urban</option>
                                                        <option>Kolar</option>
                                                        <option>Ramanagara</option>
														<option>Shivamogga/Shimoga</option>
														<option>Dakshina Kannada/Mangalore</option>
														<option>Kodagu</option>
                                                        <option>Chamarajanagara</option>
														<option>Bidar</option>
														<option>Bellary/Ballari</option>
														<option>Kalaburagi/Gulbarga</option>
														<option>Yadgiri</option>
														<option>Raichuru</option>
														<option>Bagalkote</option>
														<option>Belagavi/Belgaum</option>
														<option>Koppala</option>
														<option>Gadaga</option>
														<option>Vijayapura/Bijapur</option>
														<option>Dharwada</option>
														<option>Uttar Kannada/Karwar</option>
														<option>Haveri</option>
														<option>Vijayanagara</option>
														<option>Davangere</option>
														<option>Chitradurga</option>
														<option>Udupi</option>
														<option>Tumakuru/Tumkur</option>
														<option>Mandya</option>
														<option>Hassana</option>
														<option>Chikkmagaluru/Chikmagalur</option>
														<option>Kodagu</option>
														<option>Chikkaballapura</option>
													</select>
												</div>
											</div>
                                           
                                           
                                          
                                          
                                            <div class="row">
											<div class="col-sm-9 col-sm-offset-5">
												<button class="btn btn-primary">Submit</button>
												<button type="reset" class="btn btn-default">Reset</button>
											</div>
										</div>
						
											
						
										
						
						
											
						
											</div>
						
										
										</form>
									</div>
								</section>
						
		</section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Specific Page Vendor -->
		<script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
		<script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>

	</body>
    <?php } ?>  
</html>