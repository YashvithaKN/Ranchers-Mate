
<?php 
require('db.php');

$a=$_POST['fid'];
$b=$_POST['fname'];
$c=$_POST['ftype'];
$d=$_POST['fimage'];
$e=$_POST['fabout'];
$f=$_POST['images'];
if(empty($d)){

$d=$f;


if($con){
	echo"connection successful";
    $query = "UPDATE  `fertilizer` SET fname='$b',ftype='$c',image='$d',about='$e' WHERE  fid='$a'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Updated successfully  ");
            window.location="viewf.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="viewf.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}
}else{
    if($con){
        echo"connection successful";
        $query = "UPDATE  `fertilizer` SET fname='$b',ftype='$c',image='$d',about='$e' WHERE  fid='$a'";
    
        if (mysqli_query($con, $query)) {
                   echo "New record created successfully";?>
                           <script type="text/javascript">
                window.alert("Updated successfully  ");
                window.location="viewf.php";
                </script>
                <?php 
                }
        else{
            echo"Record not inserted";?>
            <script type="text/javascript">
                window.alert("Updated failed ");
                window.location="viewf.php";
                </script>
                <?php 
        }
    }
    else{
        echo"connection error";
    
    }
}
?>








