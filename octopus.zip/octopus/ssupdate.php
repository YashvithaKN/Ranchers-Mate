
<?php 
require('db.php');

$a=$_POST['sid'];
$b=$_POST['stype'];
$c=$_POST['sarea'];





if($con){
	echo"connection successful";
    $query = "UPDATE  `soil` SET sname='$b',sarea='$c' WHERE  sid='$a'";

	if (mysqli_query($con, $query)) {
               echo "New record created successfully";?>
			   		<script type="text/javascript">
            window.alert("Updated successfully  ");
            window.location="vsoil.php";
            </script>
			<?php 
            }
	else{
		echo"Record not inserted";?>
		<script type="text/javascript">
            window.alert("Updated failed ");
            window.location="vsoil.php";
            </script>
			<?php 
	}
}
else{
	echo"connection error";

}
?>








