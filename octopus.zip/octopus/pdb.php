<?php 
	session_start();
	
	include("db.php");	
	 {	
		//$res = $conn->query($sql);
		
		// if ($res->num_rows==0)
    {
		
		 $a = $_POST['fname'];
		 $b = $_POST['pname'];
         $c = $_POST['p4'];
         $d = $_POST['price'];
         $e = $_POST['about'];

		 $sql = "INSERT INTO products (fname,pname,pimage,pprice,about) VALUES ('$a','$b','$c','$d','$e')";
			if($con->query($sql))
			{?>
                
				
               <script type="text/javascript">
            window.alert("successfully INFO Added");
            window.location="ap.php";
            </script>
			<?php 
			}
			else
			{
				echo "failed";
			}
		
			
		}
     }
?>

