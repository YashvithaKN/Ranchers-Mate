<?php
$db="ranchers";
$user="root";
$pass="";
$server="localhost";
$a = $_GET['username'];



$con=mysqli_connect($server,$user,$pass,$db);
if($con){
	
	$sql="delete from susers where username='$a'";
	if($con->query($sql)===TRUE){
		echo"Record deleted";?>
		<script type="text/javascript">
            window.alert("Record successfully deleted");
            window.location="vuu.php";
            </script>
			<?php 
}else{
	echo"connection error";
}
}
?>