<?php
// Function to check password strength
function isPasswordStrong($password)
{
    // Add your password strength validation logic here
    // For example, check for a minimum length, presence of uppercase, lowercase, and special characters
    $pattern = '/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/';
    return preg_match($pattern, $password);
}

if (isset($_POST['password'])) {
    $password = $_POST['password'];

    if (isPasswordStrong($password)) {
        echo "<span style='color: white;'>Strong password</span>";
    } else {
        echo "<span style='color: white;'>Weak password</span>";
    }
}
?>
